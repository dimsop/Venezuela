.. |company| replace:: ADHOC SA

.. |icon| image:: https://raw.githubusercontent.com/ingadhoc/maintainer-tools/master/resources/adhoc-icon.png

.. image:: https://img.shields.io/badge/license-AGPL--3-blue.png
   :target: https://www.gnu.org/licenses/agpl
   :alt: License: AGPL-3

========================================
Payment Groups with Accounting Documents
========================================

Integration between Payment Groups and Accounting Documents

Installation
============

To install this module, you need to:

#. This module is auto-installed

Credits
=======

* |company| |icon|
