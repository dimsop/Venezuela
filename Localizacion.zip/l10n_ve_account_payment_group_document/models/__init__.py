from . import account_chart_template
from . import account_payment_group
from . import account_payment_receiptbook
from . import l10n_latam_document_type
from . import account_move
