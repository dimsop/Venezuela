# -*- coding: utf-8 -*-
################################################################################
# Author: SINAPSYS GLOBAL SA || MASTERCORE SAS
# Copyleft: 2020-Present.
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).
#
#
################################################################################
from . import l10n_latam_identification_type
from . import l10n_ve_responsibility_type
from . import res_partner
from . import res_bank
from . import res_partner_bank
from . import res_company
from . import res_currency_rate
